Justin Igmen
200364880
ENSE350 Lab 4

**Please use Visual studio to run this program**

Step 1: Prompt user to enter size of matrix and its values.
Step 2: Set the L matrix as the identity matrix and U matrix as equal to the original matrix
Step 3a: L matrix calculation
	i: Element is equal to the u element divided by the u_ii (row = column) element
Step 3b: U matrix calculation
	i: Set up another for loop
	ii: Current element u is equal to itself minus l[j][i] times u[i][k]
Step 4: Display solutions 